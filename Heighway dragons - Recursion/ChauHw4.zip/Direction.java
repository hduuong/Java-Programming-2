/**
 * an enum class that specify the input of direction
 * @author Duong Chau
 * @version HW2
 */
public enum Direction {
    NORTH, SOUTH;
  }