public class InvalidExpressionException extends Exception{
  InvalidExpressionException(){
    
  }
  InvalidExpressionException(String message){
    
  }
}