public interface Position {
  
  public Object element();
  public Position parent();
  public Position leftChild();
  public Position rightChild();
  
}